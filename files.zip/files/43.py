
#Code Reusability

def sum(a, b):
    print('The Sum : ', a + b)
sum(10,20)
sum(20,30)
sum(30,40)
sum(40,50)
sum(50,60)

'''
a = 20
b = 10
print('The Sum : ', a + b)

a = 30
b = 20
print('The Sum : ', a + b)

a = 40
b = 30
print('The Sum : ', a + b)

a = 50
b = 40
print('The Sum : ', a + b)

a = 60
b = 50
print('The Sum : ', a + b)

a = 70
b = 60
print('The Sum : ', a + b)
'''